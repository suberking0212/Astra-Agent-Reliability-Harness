# Astra Agent Reliability Harness

Phase 2 implements the first contract-based Astra × Hermes business vertical
slice without modifying the Hermes Agent Loop.

```text
RuntimeInvocation
→ HermesExecutor
→ fixed astra_bridge project plugin
→ AstraToolGateway
→ SQLite-backed MockBusinessService
→ submit_task_result
→ ResultReceipt
→ ExecutionResult
→ NeutralTraceCollector
```

## Run the deterministic test suite

```bash
pytest -q
```

The normal complaint E2E test uses a scripted provider boundary while keeping
the real Hermes plugin discovery, tool registry, Agent Loop, tool execution,
observer hooks, and SessionDB persistence.

## Opt in to the live Provider smoke test

The live test is skipped by default and never blocks ordinary CI.

```bash
export ASTRA_RUN_LIVE_PROVIDER=1
export ASTRA_LIVE_BASE_URL="https://provider.example/v1"
export ASTRA_LIVE_API_KEY="..."
export ASTRA_LIVE_MODEL="model-name"
# Optional: ASTRA_LIVE_PROVIDER and ASTRA_LIVE_API_MODE
pytest -q tests/test_phase2_live_provider.py
```

Business side effects remain confined to the local Mock Business Service.

## Reproduce the Phase 2 Core audit and baseline

```bash
python3 scripts/run_phase2_core_audit.py
pytest -q tests/test_phase2_stress.py
python3 scripts/freeze_phase2_core_baseline.py
```

Generated evidence is stored under `artifacts/phase2-core-runtime-audit/`.
The frozen source archive and manifest are written to
`artifacts/phase2-core-baseline-source.tar.gz` and
`artifacts/phase2-core-baseline-manifest.json`.

## Package boundaries

- `astra/domain.py`: Hermes-independent executor, event, result, and tool ports.
- `astra/hermes_adapter/`: the only layer allowed to import Hermes.
- `astra/tool_gateway.py`: whitelist, schema, permission, suspension, receipt,
  and idempotency enforcement.
- `astra/result_validator.py`: minimal contract/business-state validation.
- `astra/storage.py`: SQLite persistence and exactly-once termination.
- `astra/runtime.py`: persisted interaction resolution and new-turn resume.
- `astra/budget.py`: observe-only/conservative usage ledger.
- `astra/trace.py`: neutral, non-intervening trace collection.
