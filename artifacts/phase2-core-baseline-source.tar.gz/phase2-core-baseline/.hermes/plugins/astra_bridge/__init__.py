"""Hermes project-plugin entry point for the Astra bridge."""

from astra.hermes_adapter.bridge import register

__all__ = ["register"]
